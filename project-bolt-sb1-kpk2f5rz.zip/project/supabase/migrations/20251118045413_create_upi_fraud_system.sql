/*
  # UPI Fraud Detection System Database Schema

  1. New Tables
    - `upi_checks`
      - `id` (uuid, primary key)
      - `upi_id` (text, the UPI ID being checked)
      - `is_suspicious` (boolean, fraud detection result)
      - `domain` (text, extracted domain from UPI)
      - `checked_at` (timestamptz, when the check was performed)
      - `ip_address` (text, optional user IP for tracking)
    
    - `upi_reports`
      - `id` (uuid, primary key)
      - `upi_id` (text, the reported UPI ID)
      - `report_reason` (text, why it was reported)
      - `reported_at` (timestamptz, when it was reported)
      - `reporter_email` (text, optional reporter contact)
    
    - `upi_transactions`
      - `id` (uuid, primary key)
      - `upi_id` (text, the UPI ID involved)
      - `transaction_date` (timestamptz, when transaction occurred)
      - `amount` (numeric, transaction amount)
      - `status` (text, transaction status)
    
  2. Security
    - Enable RLS on all tables
    - Add policies for public read access (fraud detection is a public service)
    - Add policies for public insert on checks and reports
*/

-- Create upi_checks table
CREATE TABLE IF NOT EXISTS upi_checks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  upi_id text NOT NULL,
  is_suspicious boolean DEFAULT false,
  domain text,
  checked_at timestamptz DEFAULT now(),
  ip_address text
);

-- Create upi_reports table
CREATE TABLE IF NOT EXISTS upi_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  upi_id text NOT NULL,
  report_reason text,
  reported_at timestamptz DEFAULT now(),
  reporter_email text
);

-- Create upi_transactions table
CREATE TABLE IF NOT EXISTS upi_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  upi_id text NOT NULL,
  transaction_date timestamptz DEFAULT now(),
  amount numeric DEFAULT 0,
  status text DEFAULT 'completed'
);

-- Enable RLS
ALTER TABLE upi_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE upi_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE upi_transactions ENABLE ROW LEVEL SECURITY;

-- Policies for upi_checks (public read and insert for fraud checking)
CREATE POLICY "Anyone can view UPI checks"
  ON upi_checks FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert UPI checks"
  ON upi_checks FOR INSERT
  WITH CHECK (true);

-- Policies for upi_reports (public read and insert for community reporting)
CREATE POLICY "Anyone can view UPI reports"
  ON upi_reports FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert UPI reports"
  ON upi_reports FOR INSERT
  WITH CHECK (true);

-- Policies for upi_transactions (public read for fraud detection)
CREATE POLICY "Anyone can view UPI transactions"
  ON upi_transactions FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert UPI transactions"
  ON upi_transactions FOR INSERT
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_upi_checks_upi_id ON upi_checks(upi_id);
CREATE INDEX IF NOT EXISTS idx_upi_checks_checked_at ON upi_checks(checked_at DESC);
CREATE INDEX IF NOT EXISTS idx_upi_reports_upi_id ON upi_reports(upi_id);
CREATE INDEX IF NOT EXISTS idx_upi_transactions_upi_id ON upi_transactions(upi_id);
CREATE INDEX IF NOT EXISTS idx_upi_transactions_date ON upi_transactions(transaction_date DESC);